public interface CounterConstants {
    String INNCOMING_NG_MESSAGGE__COUNNT__KEY = "incoming-message-count";
    String OUTGOING_NG_MESSAGGE__COUNNT__KEY = "outgoing-message-count";
    String COUNT_FILE_NAME_PREFIX = "count_record";
}
